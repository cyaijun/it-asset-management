<?php

namespace PhpOffice\PhpSpreadsheet\Helper;

enum TextGridRightAlign
{
    case none;
    case numeric;
    case floatOrInt;
}
